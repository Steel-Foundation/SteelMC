//! Boss mob implementations.
