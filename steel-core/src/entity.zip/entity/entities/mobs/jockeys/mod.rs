//! Jockey mob implementations.
