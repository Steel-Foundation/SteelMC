//! Vanilla-shaped mob foundations.

mod pathfinder;

use crate::entity::leash::{LeashData, Leashable};
pub use pathfinder::PathfinderMob;
use pathfinder::tick_path_navigation_target;
#[cfg(test)]
use pathfinder::{find_ground_path_target_surface, path_end_node_can_reach_target};

use std::f32::consts::PI;
use std::sync::Arc;

use glam::DVec3;
use simdnbt::borrow::NbtCompound as BorrowedNbtCompoundView;
use simdnbt::owned::{NbtCompound, NbtTag};
use steel_math::fast_floor;
use steel_protocol::packets::game::CTakeItemEntity;
use steel_registry::attribute::AttributeRef;
use steel_registry::blocks::block_state_ext::BlockStateExt as _;
use steel_registry::data_components::components::ItemEnchantments;
use steel_registry::data_components::vanilla_components::CUSTOM_NAME;
use steel_registry::enchantment_effect::EnchantmentEffectComponent;
use steel_registry::item_stack::ItemStack;
use steel_registry::loot_table::LootTableRef;
use steel_registry::sound_event::SoundEventRef;
use steel_registry::vanilla_block_tags::BlockTag;
use steel_registry::{
    REGISTRY, RegistryExt, TaggedRegistryExt, vanilla_attributes, vanilla_damage_types,
    vanilla_entities, vanilla_game_events, vanilla_game_rules,
};
use steel_utils::locks::SyncMutex;
use steel_utils::types::{Difficulty, InteractionHand};
use steel_utils::{BlockPos, ChunkPos, Downcast as _, Identifier, WorldAabb, axis::Axis};

use crate::behavior::{BLOCK_BEHAVIORS, BlockCollisionContext, ITEM_BEHAVIORS, InteractionResult};
use crate::enchantment_helper::{self, EnchantmentDamageContext, EnchantmentPostAttackContext};
use crate::entity::ai::control::{
    BodyRotationInput, MobControls, MoveControlOperation, rotate_if_necessary, rotate_towards,
};
use crate::entity::ai::goal::{GoalControl, GoalSelector};
use crate::entity::ai::navigation::PathNavigation;
use crate::entity::ai::path::{PathType, PathfindingContext, PathfindingMalus};
use crate::entity::ai::sensing::Sensing;
use crate::entity::ai::walk::WalkPathEvaluator;
use crate::entity::attribute::{AttributeModifier, AttributeModifierOperation};
use crate::entity::damage::DamageSource;
use crate::entity::entities::objects::items::ItemEntity;
use crate::entity::{
    Entity, EntitySpawnReason, LivingEntity, LivingTravelInput, RemovalReason, SharedEntity,
    SpawnGroupData, WeakEntity,
};
use crate::inventory::equipment::EquipmentSlot;
use crate::physics::MoveResult;
use crate::player::Player;
use crate::world::{LevelReader, World};

const MOB_FLAG_NO_AI: i8 = 1;
const MOB_FLAG_LEFT_HANDED: i8 = 2;
const MOB_FLAG_AGGRESSIVE: i8 = 4;
const MOVE_CONTROL_MIN_SPEED_SQR: f64 = 2.500_000_3e-7;
const MOVE_CONTROL_MAX_TURN: f32 = 90.0;
const DEFAULT_EQUIPMENT_DROP_CHANCE: f32 = 0.085;
/// Vanilla bias subtracted from the roll before comparing against a slot's drop
/// chance when a mob swaps out worn gear it picked something better up over.
const REPLACED_EQUIPMENT_DROP_BIAS: f32 = 0.1;
const PRESERVE_ITEM_DROP_CHANCE_THRESHOLD: f32 = 1.0;
const PRESERVE_ITEM_DROP_CHANCE: f32 = 2.0;
const BODY_ROTATION_MOVING_DISTANCE_SQR: f64 = 2.500_000_3e-7;
const TARGET_REACH_DISTANCE_SQR: f64 = 2.25;
const DEFAULT_ATTACK_REACH_BASE: f32 = 2.04;
const DEFAULT_ATTACK_REACH_OFFSET: f32 = 0.6;
const RANDOM_SPAWN_BONUS_ID: Identifier = Identifier::vanilla_static("random_spawn_bonus");
const RANDOM_SPAWN_BONUS_SCALE: f64 = 0.114_850_000_000_000_01;
const LEFT_HANDED_SPAWN_CHANCE: f32 = 0.05;
/// Vanilla `Mob.ITEM_PICKUP_REACH`: the per-axis distance the item-pickup search
/// box is inflated by when a mob looks for nearby dropped items to collect.
const ITEM_PICKUP_REACH: DVec3 = DVec3::new(1.0, 0.0, 1.0);

#[derive(Debug, Clone, Copy, PartialEq)]
struct DropChances {
    by_equipment: [f32; EquipmentSlot::ALL.len()],
}

impl DropChances {
    const DEFAULT: Self = Self {
        by_equipment: [DEFAULT_EQUIPMENT_DROP_CHANCE; EquipmentSlot::ALL.len()],
    };

    #[must_use]
    const fn by_equipment(self, slot: EquipmentSlot) -> f32 {
        self.by_equipment[slot.index()]
    }

    const fn set_guaranteed_drop(&mut self, slot: EquipmentSlot) {
        self.by_equipment[slot.index()] = PRESERVE_ITEM_DROP_CHANCE;
    }

    fn set_equipment_chance(&mut self, slot: EquipmentSlot, chance: f32) -> bool {
        if chance < 0.0 {
            return false;
        }

        self.by_equipment[slot.index()] = chance;
        true
    }

    #[must_use]
    fn is_preserved(self, slot: EquipmentSlot) -> bool {
        self.by_equipment(slot) > PRESERVE_ITEM_DROP_CHANCE_THRESHOLD
    }

    fn save(self, nbt: &mut NbtCompound) {
        if self == Self::DEFAULT {
            return;
        }

        let mut drop_chances = NbtCompound::new();
        for slot in EquipmentSlot::ALL {
            let chance = self.by_equipment(slot);
            if chance.to_bits() != DEFAULT_EQUIPMENT_DROP_CHANCE.to_bits() {
                drop_chances.insert(slot.name(), chance);
            }
        }

        nbt.insert("drop_chances", NbtTag::Compound(drop_chances));
    }

    fn load(nbt: BorrowedNbtCompoundView<'_, '_>) -> Self {
        let Some(drop_chances) = nbt.compound("drop_chances") else {
            return Self::DEFAULT;
        };

        let mut loaded = Self::DEFAULT;
        for slot in EquipmentSlot::ALL {
            let Some(chance) = drop_chances.float(slot.name()) else {
                continue;
            };
            if !loaded.set_equipment_chance(slot, chance) {
                return Self::DEFAULT;
            }
        }

        loaded
    }
}

#[derive(Debug)]
pub struct MobBase {
    goal_selector: SyncMutex<GoalSelector>,
    target_selector: SyncMutex<GoalSelector>,
    target: SyncMutex<Option<WeakEntity>>,
    sensing: SyncMutex<Sensing>,
    controls: SyncMutex<MobControls>,
    navigation: SyncMutex<PathNavigation>,
    pathfinding_malus: SyncMutex<PathfindingMalus>,
    persistence_required: SyncMutex<bool>,
    can_pick_up_loot: SyncMutex<bool>,
    drop_chances: SyncMutex<DropChances>,
    home_restriction: SyncMutex<MobHomeRestriction>,
    death_loot_table: SyncMutex<Option<Identifier>>,
    death_loot_table_seed: SyncMutex<i64>,
    leash_data: SyncMutex<Option<LeashData>>,
    ambient_sound_time: SyncMutex<i32>,
    xp_reward: SyncMutex<i32>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct MobHomeRestriction {
    position: BlockPos,
    radius: i32,
}
impl MobHomeRestriction {
    const fn none() -> Self {
        Self {
            position: BlockPos::ZERO,
            radius: -1,
        }
    }
}

impl MobBase {
    #[must_use]
    pub fn new() -> Self {
        Self {
            goal_selector: SyncMutex::new(GoalSelector::new()),
            target_selector: SyncMutex::new(GoalSelector::new()),
            target: SyncMutex::new(None),
            sensing: SyncMutex::new(Sensing::new()),
            controls: SyncMutex::new(MobControls::new()),
            navigation: SyncMutex::new(PathNavigation::new()),
            pathfinding_malus: SyncMutex::new(PathfindingMalus::new()),
            persistence_required: SyncMutex::new(false),
            can_pick_up_loot: SyncMutex::new(false),
            drop_chances: SyncMutex::new(DropChances::DEFAULT),
            home_restriction: SyncMutex::new(MobHomeRestriction::none()),
            death_loot_table: SyncMutex::new(None),
            death_loot_table_seed: SyncMutex::new(0),
            leash_data: SyncMutex::new(None),
            ambient_sound_time: SyncMutex::new(0),
            xp_reward: SyncMutex::new(0),
        }
    }

    #[must_use]
    pub const fn goal_selector(&self) -> &SyncMutex<GoalSelector> {
        &self.goal_selector
    }

    #[must_use]
    pub const fn target_selector(&self) -> &SyncMutex<GoalSelector> {
        &self.target_selector
    }

    #[must_use]
    pub(crate) const fn sensing(&self) -> &SyncMutex<Sensing> {
        &self.sensing
    }

    #[must_use]
    pub fn target(&self, is_valid: impl Fn(&dyn LivingEntity) -> bool) -> Option<SharedEntity> {
        let mut target = self.target.lock();
        let Some(upgraded) = target.as_ref().and_then(WeakEntity::upgrade) else {
            *target = None;
            return None;
        };
        let living_target = upgraded.as_living_entity()?;
        if !is_valid(living_target) {
            return None;
        }
        Some(upgraded)
    }

    pub fn set_target(
        &self,
        target: Option<&SharedEntity>,
        is_valid: impl Fn(&dyn LivingEntity) -> bool,
    ) -> bool {
        let Some(target) = target else {
            *self.target.lock() = None;
            return true;
        };
        if !target.is_living_entity() {
            return false;
        }
        let Some(living_target) = target.as_living_entity() else {
            return false;
        };
        if !is_valid(living_target) {
            *self.target.lock() = None;
            return false;
        }

        *self.target.lock() = Some(Arc::downgrade(target));
        true
    }

    #[must_use]
    pub const fn controls(&self) -> &SyncMutex<MobControls> {
        &self.controls
    }

    #[must_use]
    pub const fn navigation(&self) -> &SyncMutex<PathNavigation> {
        &self.navigation
    }

    #[must_use]
    pub const fn pathfinding_malus(&self) -> &SyncMutex<PathfindingMalus> {
        &self.pathfinding_malus
    }

    #[must_use]
    pub const fn persistence_required(&self) -> &SyncMutex<bool> {
        &self.persistence_required
    }

    pub const fn can_pick_up_loot(&self) -> &SyncMutex<bool> {
        &self.can_pick_up_loot
    }

    const fn drop_chances(&self) -> &SyncMutex<DropChances> {
        &self.drop_chances
    }

    const fn home_restriction(&self) -> &SyncMutex<MobHomeRestriction> {
        &self.home_restriction
    }

    const fn death_loot_table(&self) -> &SyncMutex<Option<Identifier>> {
        &self.death_loot_table
    }

    const fn death_loot_table_seed(&self) -> &SyncMutex<i64> {
        &self.death_loot_table_seed
    }

    const fn leash_data(&self) -> &SyncMutex<Option<LeashData>> {
        &self.leash_data
    }

    #[must_use]
    pub fn ambient_sound_time(&self) -> i32 {
        *self.ambient_sound_time.lock()
    }

    pub fn set_ambient_sound_time(&self, ambient_sound_time: i32) {
        *self.ambient_sound_time.lock() = ambient_sound_time;
    }

    fn get_and_increment_ambient_sound_time(&self) -> i32 {
        let mut ambient_sound_time = self.ambient_sound_time.lock();
        let previous = *ambient_sound_time;
        *ambient_sound_time += 1;
        previous
    }

    #[must_use]
    pub fn xp_reward(&self) -> i32 {
        *self.xp_reward.lock()
    }

    pub fn set_xp_reward(&self, xp_reward: i32) {
        *self.xp_reward.lock() = xp_reward;
    }
}

impl Default for MobBase {
    fn default() -> Self {
        Self::new()
    }
}

pub trait Mob: LivingEntity + Leashable {
    fn mob_base(&self) -> &MobBase;

    fn mob_flags(&self) -> i8;

    fn set_mob_flags(&self, flags: i8);

    /// Returns vanilla `Mob.isSaddled`.
    fn is_saddled(&self) -> bool {
        let mut is_saddled = false;
        self.with_equipment_slot(EquipmentSlot::Saddle, &mut |item_stack| {
            is_saddled = self.is_equippable_in_slot(item_stack, EquipmentSlot::Saddle);
        });
        is_saddled
    }

    fn custom_server_ai_step(&self) {}

    /// Runs vanilla `Mob.ate`, invoked after an eating goal resolves a block.
    fn ate(&self) {}

    fn tick_goal_selectors(&self) {}

    fn xp_reward(&self) -> i32 {
        self.mob_base().xp_reward()
    }

    fn set_xp_reward(&self, xp_reward: i32) {
        self.mob_base().set_xp_reward(xp_reward);
    }

    /// Returns vanilla `Mob.getTarget`.
    fn target(&self) -> Option<SharedEntity> {
        self.mob_base()
            .target(|target| self.is_valid_target(target))
    }

    /// Sets vanilla `Mob.target`.
    ///
    /// Returns `false` when the supplied entity is not a living entity.
    fn set_target(&self, target: Option<&SharedEntity>) -> bool {
        self.mob_base()
            .set_target(target, |target| self.is_valid_target(target))
    }

    fn is_valid_target(&self, target: &dyn LivingEntity) -> bool {
        if target
            .as_player()
            .is_some_and(|player| player.has_infinite_materials() || player.is_spectator())
        {
            return false;
        }

        Mob::can_attack(self, target)
    }

    /// Returns vanilla `Mob.canAttack`.
    fn can_attack(&self, target: &dyn LivingEntity) -> bool {
        target.entity_type() != &vanilla_entities::GHAST && LivingEntity::can_attack(self, target)
    }

    fn base_experience_reward_mob(&self) -> i32 {
        let xp_reward = self.xp_reward();
        if xp_reward <= 0 {
            return xp_reward;
        }

        let mut result = xp_reward;
        for slot in EquipmentSlot::ALL {
            if !slot.can_increase_experience() {
                continue;
            }

            let should_increase = {
                let equipment = self.living_base().equipment().lock();
                !equipment.get_ref(slot).is_empty() && self.equipment_drop_chance(slot) <= 1.0
            };
            if should_increase {
                result += 1 + rand::random_range(0..3);
            }
        }
        result
    }

    fn ambient_sound_interval(&self) -> i32 {
        if let Some(animal) = self.as_animal() {
            return animal.ambient_sound_interval_animal();
        }

        80
    }

    fn ambient_sound(&self) -> Option<SoundEventRef> {
        None
    }

    fn play_ambient_sound(&self) {
        self.make_sound(self.ambient_sound());
    }

    fn reset_ambient_sound_time(&self) {
        self.mob_base()
            .set_ambient_sound_time(-self.ambient_sound_interval());
    }

    /// Runs vanilla `Mob.baseTick`.
    fn base_tick_mob(&self) {
        self.base_tick_living_entity();
        self.mob_base_tick();
    }

    /// Runs the mob-owned portion of vanilla `Mob.baseTick`.
    fn mob_base_tick(&self) {
        if !LivingEntity::is_alive(self) {
            return;
        }

        let ambient_sound_time = self.mob_base().get_and_increment_ambient_sound_time();
        if rand::random_range(0..1000) < ambient_sound_time {
            self.reset_ambient_sound_time();
            self.play_ambient_sound();
        }
    }

    fn finalize_spawn(
        &self,
        world: &Arc<World>,
        spawn_reason: EntitySpawnReason,
        group_data: Option<SpawnGroupData>,
    ) -> Option<SpawnGroupData> {
        self.finalize_spawn_mob_base(world, spawn_reason, group_data)
    }

    fn finalize_spawn_mob_base(
        &self,
        _world: &Arc<World>,
        _spawn_reason: EntitySpawnReason,
        group_data: Option<SpawnGroupData>,
    ) -> Option<SpawnGroupData> {
        let needs_random_spawn_bonus = !self
            .attributes()
            .lock()
            .has_modifier(vanilla_attributes::FOLLOW_RANGE, &RANDOM_SPAWN_BONUS_ID);
        let random_spawn_bonus = needs_random_spawn_bonus
            .then(|| RANDOM_SPAWN_BONUS_SCALE * (rand::random::<f64>() - rand::random::<f64>()));
        let left_handed = rand::random::<f32>() < LEFT_HANDED_SPAWN_CHANCE;

        if let Some(amount) = random_spawn_bonus {
            self.attributes().lock().add_modifier(
                vanilla_attributes::FOLLOW_RANGE,
                AttributeModifier {
                    id: RANDOM_SPAWN_BONUS_ID,
                    amount,
                    operation: AttributeModifierOperation::AddMultipliedBase,
                },
                true,
            );
        }
        self.set_left_handed(left_handed);
        group_data
    }

    /// Handles vanilla `Mob.interact`.
    fn interact_mob(
        &self,
        player: &Player,
        hand: InteractionHand,
        location: DVec3,
    ) -> InteractionResult {
        if !LivingEntity::is_alive(self) {
            return InteractionResult::Pass;
        }

        // TODO: Handle name tags and spawn eggs once item-on-entity behavior exists.
        let interaction_result = self.interact_entity(player, hand, location);
        if interaction_result != InteractionResult::Pass {
            return interaction_result;
        }

        let interaction_result = self.mob_interact(player, hand);
        if interaction_result.consumes_action() {
            self.game_event_with_source_entity(&vanilla_game_events::ENTITY_INTERACT, Some(player));
        }

        interaction_result
    }

    /// Handles vanilla `Mob.mobInteract`.
    fn mob_interact(&self, _player: &Player, _hand: InteractionHand) -> InteractionResult {
        InteractionResult::Pass
    }

    /// Returns vanilla `Mob.canShearEquipment`.
    fn can_shear_equipment(&self, _player: &Player) -> bool {
        !self.is_vehicle()
    }

    /// Applies vanilla `Mob.usePlayerItem`.
    fn use_player_item(&self, player: &Player, hand: InteractionHand) {
        player.inventory.lock().shrink_item_in_hand(hand, 1);
        // TODO: Apply USE_REMAINDER components once item use-remainder support exists.
    }

    fn remove_when_far_away(&self, dist_sqr: f64) -> bool {
        self.as_animal()
            .is_none_or(|animal| animal.remove_when_far_away_animal(dist_sqr))
    }

    fn requires_custom_persistence(&self) -> bool {
        self.is_passenger() || self.is_leashed()
    }

    fn is_persistence_required(&self) -> bool {
        *self.mob_base().persistence_required().lock()
    }

    fn set_persistence_required(&self) {
        *self.mob_base().persistence_required().lock() = true;
    }

    /// Returns vanilla `Mob.canPickUpLoot`.
    fn can_pick_up_loot(&self) -> bool {
        *self.mob_base().can_pick_up_loot().lock()
    }

    fn set_can_pick_up_loot(&self, can_pick_up_loot: bool) {
        *self.mob_base().can_pick_up_loot().lock() = can_pick_up_loot;
    }

    fn equipment_drop_chance(&self, slot: EquipmentSlot) -> f32 {
        self.mob_base().drop_chances().lock().by_equipment(slot)
    }

    fn is_equipment_drop_preserved(&self, slot: EquipmentSlot) -> bool {
        self.mob_base().drop_chances().lock().is_preserved(slot)
    }

    fn set_guaranteed_drop(&self, slot: EquipmentSlot) {
        self.mob_base()
            .drop_chances()
            .lock()
            .set_guaranteed_drop(slot);
    }

    /// Vanilla `Mob.getPickupReach`: the per-axis distance the item-pickup search
    /// box is inflated by. Overridable so mobs with a longer reach can widen it.
    fn get_pickup_reach(&self) -> DVec3 {
        ITEM_PICKUP_REACH
    }

    /// Vanilla `Mob.wantsToPickUp`: whether this mob wants to collect the item it
    /// just walked over. Defaults to whatever the mob is willing to hold.
    fn wants_to_pick_up(&self, item_stack: &ItemStack) -> bool {
        self.can_hold_item(item_stack)
    }

    /// Vanilla `Mob.canHoldItem`: whether this mob is willing to hold the item.
    /// The base mob holds anything; specific mobs narrow this down.
    fn can_hold_item(&self, _item_stack: &ItemStack) -> bool {
        true
    }

    /// Vanilla `Mob.pickUpItem`: take a dropped item into this mob's equipment.
    ///
    /// Delegates the slot routing and gear-swap decision to
    /// [`equip_item_if_possible`](Self::equip_item_if_possible), then shrinks the
    /// source stack by however much was equipped, only removing the item entity
    /// once nothing is left.
    fn pick_up_item(&self, world: &Arc<World>, item_entity: &ItemEntity) {
        let equipped = self.equip_item_if_possible(item_entity.get_item());
        if equipped.is_empty() {
            return;
        }

        let count = equipped.count();
        // TODO(advancements): vanilla calls LivingEntity.onItemPickup here, before
        // the take packet, which fires the THROWN_ITEM_PICKED_UP_BY_ENTITY criterion.
        // Add that once Steel has the advancement-criteria foundation.
        let chunk_pos = ChunkPos::from_entity_pos(item_entity.position());
        world.broadcast_to_nearby(
            chunk_pos,
            CTakeItemEntity::new(item_entity.id(), self.id(), count),
            None,
        );

        let mut remaining = item_entity.get_item();
        remaining.shrink(count);
        if remaining.is_empty() {
            item_entity.set_removed(RemovalReason::Discarded);
        } else {
            item_entity.set_item(remaining);
        }
    }

    /// Vanilla `Mob.equipItemIfPossible`: route `item_stack` to the slot its
    /// equippable component asks for (main hand otherwise), swap up when the
    /// target slot already holds worse gear, and drop the replaced piece by its
    /// drop chance. Returns the stack that was equipped, or empty when nothing
    /// was taken.
    fn equip_item_if_possible(&self, mut item_stack: ItemStack) -> ItemStack {
        let mut slot = self.get_equipment_slot_for_item(&item_stack);
        if !self.is_equippable_in_slot(&item_stack, slot) {
            return ItemStack::empty();
        }

        let mut current = self.equipment_in_slot(slot);
        let mut can_replace = self.can_replace_current_item(&item_stack, &current, slot);
        // Armor that would not be an upgrade still gets a chance to be carried in
        // the main hand instead, provided that hand is free.
        if slot.is_armor() && !can_replace {
            slot = EquipmentSlot::MainHand;
            current = self.equipment_in_slot(slot);
            can_replace = current.is_empty();
        }

        if !can_replace || !self.can_hold_item(&item_stack) {
            return ItemStack::empty();
        }

        let drop_chance = self.equipment_drop_chance(slot);
        if !current.is_empty()
            && (rand::random::<f32>() - REPLACED_EQUIPMENT_DROP_BIAS).max(0.0) < drop_chance
        {
            self.spawn_at_location(current, 0.0);
        }

        let to_equip = slot.limit(&mut item_stack);
        let equipped = to_equip.copy_with_count(to_equip.count());
        self.living_base().equipment().lock().set(slot, to_equip);
        self.set_guaranteed_drop(slot);
        self.set_persistence_required();
        equipped
    }

    /// Vanilla `LivingEntity.getEquipmentSlotForItem`: the slot an item wants to
    /// occupy, falling back to the main hand when it is not equippable or the mob
    /// cannot use that slot.
    fn get_equipment_slot_for_item(&self, item_stack: &ItemStack) -> EquipmentSlot {
        match item_stack.get_equippable() {
            Some(equippable) if self.can_use_slot(equippable.slot) => equippable.slot,
            _ => EquipmentSlot::MainHand,
        }
    }

    /// Returns a copy of whatever this mob currently holds in `slot`.
    fn equipment_in_slot(&self, slot: EquipmentSlot) -> ItemStack {
        let equipment = self.living_base().equipment().lock();
        let stack = equipment.get_ref(slot);
        stack.copy_with_count(stack.count())
    }

    /// Vanilla `Mob.canReplaceCurrentItem`: whether the freshly picked-up item
    /// should displace what is already in `slot`.
    fn can_replace_current_item(
        &self,
        new_item_stack: &ItemStack,
        current_item_stack: &ItemStack,
        slot: EquipmentSlot,
    ) -> bool {
        if current_item_stack.is_empty() {
            true
        } else if slot.is_armor() {
            self.compare_armor(new_item_stack, current_item_stack, slot)
        } else if slot == EquipmentSlot::MainHand {
            self.compare_weapons(new_item_stack, current_item_stack, slot)
        } else {
            false
        }
    }

    /// Vanilla `Mob.compareArmor`: prefer the piece granting more armor, then
    /// more toughness, then the equal-item tiebreak, unless the worn piece is
    /// protected against removal.
    #[expect(
        clippy::float_cmp,
        reason = "vanilla compares approximate attribute values for exact equality"
    )]
    fn compare_armor(
        &self,
        new_item_stack: &ItemStack,
        current_item_stack: &ItemStack,
        slot: EquipmentSlot,
    ) -> bool {
        if current_item_stack.has_enchantment_effect(EnchantmentEffectComponent::PreventArmorChange)
        {
            return false;
        }

        let new_defense =
            self.approximate_attribute_with(new_item_stack, vanilla_attributes::ARMOR, slot);
        let old_defense =
            self.approximate_attribute_with(current_item_stack, vanilla_attributes::ARMOR, slot);
        if new_defense != old_defense {
            return new_defense > old_defense;
        }

        let new_toughness = self.approximate_attribute_with(
            new_item_stack,
            vanilla_attributes::ARMOR_TOUGHNESS,
            slot,
        );
        let old_toughness = self.approximate_attribute_with(
            current_item_stack,
            vanilla_attributes::ARMOR_TOUGHNESS,
            slot,
        );
        if new_toughness == old_toughness {
            self.can_replace_equal_item(new_item_stack, current_item_stack)
        } else {
            new_toughness > old_toughness
        }
    }

    /// Vanilla `Mob.getPreferredWeaponType`: the item tag a mob favors for its
    /// main hand regardless of raw damage (a skeleton keeps its bow over a
    /// stronger sword). The base mob has no preference; specific mobs override it.
    fn get_preferred_weapon_type(&self) -> Option<Identifier> {
        None
    }

    /// Vanilla `Mob.compareWeapons`: keep a piece of the mob's preferred weapon
    /// type over one that is not, otherwise prefer more attack damage, then the
    /// equal-item tiebreak.
    #[expect(
        clippy::float_cmp,
        reason = "vanilla compares approximate attribute values for exact equality"
    )]
    fn compare_weapons(
        &self,
        new_item_stack: &ItemStack,
        current_item_stack: &ItemStack,
        slot: EquipmentSlot,
    ) -> bool {
        if let Some(preferred_weapon_type) = self.get_preferred_weapon_type() {
            let current_is_preferred = REGISTRY
                .items
                .is_in_tag(current_item_stack.item(), &preferred_weapon_type);
            let new_is_preferred = REGISTRY
                .items
                .is_in_tag(new_item_stack.item(), &preferred_weapon_type);
            if current_is_preferred && !new_is_preferred {
                return false;
            }
            if !current_is_preferred && new_is_preferred {
                return true;
            }
        }

        let new_attack_damage = self.approximate_attribute_with(
            new_item_stack,
            vanilla_attributes::ATTACK_DAMAGE,
            slot,
        );
        let old_attack_damage = self.approximate_attribute_with(
            current_item_stack,
            vanilla_attributes::ATTACK_DAMAGE,
            slot,
        );
        if new_attack_damage == old_attack_damage {
            self.can_replace_equal_item(new_item_stack, current_item_stack)
        } else {
            new_attack_damage > old_attack_damage
        }
    }

    /// Vanilla `Mob.getApproximateAttributeWith`: the value of `attribute` this
    /// mob would have in `slot` while wearing `item_stack`, taking the mob's base
    /// value (zero when it lacks the attribute) and folding in the item's
    /// attribute modifiers.
    fn approximate_attribute_with(
        &self,
        item_stack: &ItemStack,
        attribute: AttributeRef,
        slot: EquipmentSlot,
    ) -> f64 {
        let base_value = self
            .attributes()
            .lock()
            .get_base_value(attribute)
            .unwrap_or(0.0);
        item_stack
            .get_attribute_modifiers()
            .map_or(base_value, |modifiers| {
                modifiers.compute(attribute, base_value, slot)
            })
    }

    /// Vanilla `Mob.canReplaceEqualItem`: the tiebreak when two pieces grade out
    /// equally, favoring more enchantments, then less damage, then a custom name.
    fn can_replace_equal_item(
        &self,
        new_item_stack: &ItemStack,
        current_item_stack: &ItemStack,
    ) -> bool {
        let new_enchantments = new_item_stack
            .get_enchantments()
            .map_or(0, ItemEnchantments::len);
        let current_enchantments = current_item_stack
            .get_enchantments()
            .map_or(0, ItemEnchantments::len);
        if new_enchantments != current_enchantments {
            return new_enchantments > current_enchantments;
        }

        let new_damage = new_item_stack.get_damage_value();
        let current_damage = current_item_stack.get_damage_value();
        if new_damage == current_damage {
            new_item_stack.has(CUSTOM_NAME) && !current_item_stack.has(CUSTOM_NAME)
        } else {
            new_damage < current_damage
        }
    }

    /// Vanilla `Mob.aiStep` looting loop: while this mob may pick up loot and the
    /// `mobGriefing` game rule allows it, collect nearby dropped items in reach.
    fn tick_looting(&self) {
        let Some(world) = self.level() else {
            return;
        };
        if !self.can_pick_up_loot()
            || !Entity::is_alive(self)
            || !world.get_game_rule(&vanilla_game_rules::MOB_GRIEFING)
        {
            return;
        }

        let reach = self.get_pickup_reach();
        let search_box = self.bounding_box().inflate_xyz(reach.x, reach.y, reach.z);
        for entity in world.get_entities_in_aabb(&search_box) {
            let Some(item_entity) = entity.downcast_ref::<ItemEntity>() else {
                continue;
            };
            let item = item_entity.get_item();
            if item_entity.is_removed()
                || item.is_empty()
                || item_entity.has_pickup_delay()
                || !self.wants_to_pick_up(&item)
            {
                continue;
            }

            self.pick_up_item(&world, item_entity);
        }
    }

    fn drop_custom_death_loot_mob(&self, _source: &DamageSource, killed_by_player: bool) {
        if self.level().is_none() {
            return;
        }

        for slot in EquipmentSlot::ALL {
            let drop_chance = self.equipment_drop_chance(slot);
            let preserve = self.is_equipment_drop_preserved(slot);
            if !can_attempt_equipment_drop(drop_chance, preserve, killed_by_player) {
                continue;
            }

            let can_drop_item = {
                let equipment = self.living_base().equipment().lock();
                let item_stack = equipment.get_ref(slot);
                !item_stack.is_empty()
                    && !item_stack
                        .has_enchantment_effect(EnchantmentEffectComponent::PreventEquipmentDrop)
            };
            if !can_drop_item {
                continue;
            }

            // TODO: Apply EquipmentDrops enchantment value effects once damage
            // sources can resolve their living attacker context.
            let random_roll = rand::random::<f32>();
            if random_roll >= drop_chance {
                continue;
            }

            let mut item_stack = {
                let mut equipment = self.living_base().equipment().lock();
                let item_stack = equipment.get_ref(slot);
                if item_stack.is_empty()
                    || item_stack
                        .has_enchantment_effect(EnchantmentEffectComponent::PreventEquipmentDrop)
                {
                    continue;
                }

                equipment.take(slot)
            };
            if !preserve && item_stack.is_damageable_item() {
                let max_damage = item_stack.get_max_damage();
                let inner = rand::random_range(0..(max_damage - 3).max(1));
                let damage = max_damage - rand::random_range(0..=inner);
                item_stack.set_damage_value(damage);
            }

            self.spawn_at_location(item_stack, 0.0);
        }
    }

    fn save_mob(&self, nbt: &mut NbtCompound) {
        self.save_equipment(nbt);
        nbt.insert("CanPickUpLoot", i8::from(self.can_pick_up_loot()));
        nbt.insert(
            "PersistenceRequired",
            i8::from(self.is_persistence_required()),
        );
        self.mob_base().drop_chances().lock().save(nbt);
        if let Some(leash_data) = self.mob_base().leash_data().lock().as_ref() {
            leash_data.save(nbt);
        }

        if self.has_home() {
            let home = *self.mob_base().home_restriction().lock();
            nbt.insert("home_radius", home.radius);
            nbt.insert(
                "home_pos",
                NbtTag::IntArray(vec![
                    home.position.x(),
                    home.position.y(),
                    home.position.z(),
                ]),
            );
        }

        nbt.insert("LeftHanded", i8::from(self.is_left_handed()));
        if let Some(loot_table) = self.mob_base().death_loot_table().lock().as_ref() {
            nbt.insert("DeathLootTable", loot_table.to_string());
        }
        let loot_table_seed = *self.mob_base().death_loot_table_seed().lock();
        if loot_table_seed != 0 {
            nbt.insert("DeathLootTableSeed", loot_table_seed);
        }
        if self.is_no_ai() {
            nbt.insert("NoAI", i8::from(true));
        }
    }

    fn load_mob(&self, nbt: BorrowedNbtCompoundView<'_, '_>) {
        self.load_equipment(nbt);
        self.set_can_pick_up_loot(nbt.byte("CanPickUpLoot").is_some_and(|value| value != 0));
        *self.mob_base().persistence_required().lock() = nbt
            .byte("PersistenceRequired")
            .is_some_and(|value| value != 0);
        *self.mob_base().drop_chances().lock() = DropChances::load(nbt);
        *self.mob_base().leash_data().lock() = LeashData::load(nbt);
        let home_radius = nbt.int("home_radius").unwrap_or(-1);
        if home_radius >= 0 {
            let home_position = nbt
                .int_array("home_pos")
                .filter(|position| position.len() == 3)
                .map_or(BlockPos::ZERO, |position| {
                    BlockPos::new(position[0], position[1], position[2])
                });
            self.set_home_to(home_position, home_radius);
        } else {
            self.clear_home();
        }

        self.set_left_handed(nbt.byte("LeftHanded").is_some_and(|value| value != 0));
        let death_loot_table = nbt
            .string("DeathLootTable")
            .and_then(|loot_table| loot_table.to_str().as_ref().parse().ok());
        *self.mob_base().death_loot_table().lock() = death_loot_table;
        *self.mob_base().death_loot_table_seed().lock() =
            nbt.long("DeathLootTableSeed").unwrap_or(0);
        self.set_no_ai(nbt.byte("NoAI").is_some_and(|value| value != 0));
    }

    fn set_death_loot_table(&self, loot_table: Option<Identifier>) {
        *self.mob_base().death_loot_table().lock() = loot_table;
    }

    fn set_death_loot_table_seed(&self, seed: i64) {
        *self.mob_base().death_loot_table_seed().lock() = seed;
    }

    fn custom_death_loot_table(&self) -> Option<LootTableRef> {
        self.mob_base()
            .death_loot_table()
            .lock()
            .as_ref()
            .and_then(|key| REGISTRY.loot_tables.by_key(key))
    }

    fn has_custom_death_loot_table(&self) -> bool {
        self.mob_base().death_loot_table().lock().is_some()
    }

    fn death_loot_table_seed(&self) -> i64 {
        *self.mob_base().death_loot_table_seed().lock()
    }

    fn clear_custom_death_loot_table(&self) {
        *self.mob_base().death_loot_table().lock() = None;
    }

    fn is_within_home(&self) -> bool {
        self.is_within_home_pos(self.block_position())
    }

    fn is_within_home_pos(&self, pos: BlockPos) -> bool {
        let home = *self.mob_base().home_restriction().lock();
        home.radius == -1
            || block_pos_distance_sqr(home.position, pos) < home_radius_sqr(home.radius)
    }

    fn is_within_home_vec(&self, pos: DVec3) -> bool {
        let home = *self.mob_base().home_restriction().lock();
        home.radius == -1
            || block_center_distance_sqr(home.position, pos) < home_radius_sqr(home.radius)
    }

    fn set_home_to(&self, position: BlockPos, radius: i32) {
        *self.mob_base().home_restriction().lock() = MobHomeRestriction { position, radius };
    }

    fn home_position(&self) -> BlockPos {
        self.mob_base().home_restriction().lock().position
    }

    fn home_radius(&self) -> i32 {
        self.mob_base().home_restriction().lock().radius
    }

    fn clear_home(&self) {
        self.mob_base().home_restriction().lock().radius = -1;
    }

    fn has_home(&self) -> bool {
        self.home_radius() != -1
    }

    fn check_mob_despawn(&self) {
        if self
            .level()
            .is_some_and(|world| world.difficulty() == Difficulty::Peaceful)
            && !self.entity_type().allowed_in_peaceful
        {
            self.set_removed(RemovalReason::Discarded);
            return;
        }

        if self.is_persistence_required() || self.requires_custom_persistence() {
            self.set_no_action_time(0);
            return;
        }

        let Some(nearest_player_dist_sqr) = self.nearest_player_distance_sqr() else {
            return;
        };

        let mob_category = self.entity_type().mob_category;
        let despawn_distance = mob_category.despawn_distance();
        let despawn_distance_sqr = despawn_distance * despawn_distance;
        if nearest_player_dist_sqr > f64::from(despawn_distance_sqr)
            && self.remove_when_far_away(nearest_player_dist_sqr)
        {
            self.set_removed(RemovalReason::Discarded);
            return;
        }

        let no_despawn_distance = mob_category.no_despawn_distance();
        let no_despawn_distance_sqr = no_despawn_distance * no_despawn_distance;
        if self.no_action_time() > 600
            && nearest_player_dist_sqr > f64::from(no_despawn_distance_sqr)
            && self.remove_when_far_away(nearest_player_dist_sqr)
        {
            let should_discard = rand::random_range(0..800) == 0;
            if should_discard {
                self.set_removed(RemovalReason::Discarded);
            }
        } else if nearest_player_dist_sqr < f64::from(no_despawn_distance_sqr) {
            self.set_no_action_time(0);
        }
    }

    fn nearest_player_distance_sqr(&self) -> Option<f64> {
        let world = self.level()?;
        world.nearest_player_distance_sqr(self.position())
    }

    fn controlling_passenger_mob(&self) -> Option<SharedEntity> {
        let first_passenger = self.first_passenger()?;
        if self.is_no_ai() || !first_passenger.is_mob() || !first_passenger.can_control_vehicle() {
            return None;
        }

        Some(first_passenger)
    }

    fn get_pathfinding_malus(&self, path_type: PathType) -> f32 {
        self.mob_base().pathfinding_malus().lock().get(path_type)
    }

    /// Vanilla `Entity.getMaxFallDistance` baseline.
    fn max_fall_distance(&self) -> i32 {
        3
    }

    fn set_pathfinding_malus(&self, path_type: PathType, malus: f32) {
        self.mob_base()
            .pathfinding_malus()
            .lock()
            .set(path_type, malus);
    }

    fn is_no_ai(&self) -> bool {
        self.mob_flags() & MOB_FLAG_NO_AI != 0
    }

    fn set_no_ai(&self, no_ai: bool) {
        self.set_mob_flag(MOB_FLAG_NO_AI, no_ai);
    }

    fn is_left_handed(&self) -> bool {
        self.mob_flags() & MOB_FLAG_LEFT_HANDED != 0
    }

    fn set_left_handed(&self, left_handed: bool) {
        self.set_mob_flag(MOB_FLAG_LEFT_HANDED, left_handed);
    }

    fn is_aggressive(&self) -> bool {
        self.mob_flags() & MOB_FLAG_AGGRESSIVE != 0
    }

    /// Returns vanilla `Mob.getMaxHeadXRot`.
    fn max_head_x_rot(&self) -> f32 {
        40.0
    }

    /// Returns vanilla `Mob.getMaxHeadYRot`.
    fn max_head_y_rot(&self) -> f32 {
        75.0
    }

    /// Handles vanilla `Mob.doHurtTarget`.
    #[must_use]
    fn do_hurt_target(&self, world: &World, target: &SharedEntity) -> bool {
        let Some(attacker) = self.as_entity_event_source().as_living_entity() else {
            return false;
        };
        let weapon_item = {
            let mut main_hand = ItemStack::empty();
            self.with_equipment_slot(EquipmentSlot::MainHand, &mut |item_stack| {
                main_hand = item_stack.copy_with_count(item_stack.count());
            });
            main_hand
        };
        let attack_damage = self
            .attributes()
            .lock()
            .required_value(vanilla_attributes::ATTACK_DAMAGE) as f32;
        let damage_source = self.mob_attack_damage_source(&weapon_item, attacker);
        let enchantment_context = EnchantmentDamageContext::new(
            target.entity_type(),
            Some(self.entity_type()),
            Some(self.entity_type()),
            &damage_source,
        );
        let mut damage =
            enchantment_helper::modify_damage(&weapon_item, &enchantment_context, attack_damage);
        damage += ITEM_BEHAVIORS
            .get_behavior(weapon_item.item())
            .get_attack_damage_bonus(attacker, target.as_ref(), damage, &damage_source);

        let old_movement = target.velocity();
        let was_hurt = target.hurt(world, &damage_source, damage);
        if was_hurt {
            self.cause_extra_knockback(
                target.as_ref(),
                self.get_attack_knockback(target.as_ref(), &weapon_item, &damage_source),
                old_movement,
            );
            self.with_equipment_slot_mut(EquipmentSlot::MainHand, &mut |stack| {
                if stack.is_empty() {
                    return;
                }
                if let Some(living_target) = target.as_living_entity() {
                    ITEM_BEHAVIORS.get_behavior(stack.item()).hurt_enemy(
                        stack,
                        living_target,
                        attacker,
                    );
                }
            });
            let post_attack_context = EnchantmentPostAttackContext::new(
                target.as_ref(),
                Some(self.as_entity_event_source()),
                Some(self.as_entity_event_source()),
                &damage_source,
            );
            enchantment_helper::do_post_attack_effects_from_item(
                world,
                &weapon_item,
                &post_attack_context,
            );
            self.set_last_hurt_mob(Some(target));
            self.play_attack_sound();
        }

        if let Some(user) = self.as_entity_event_source().as_living_entity() {
            enchantment_helper::do_post_piercing_attack_effects(world, user);
        }
        was_hurt
    }

    /// Returns the damage source used by vanilla `ItemStack.getDamageSource`.
    fn mob_attack_damage_source(
        &self,
        weapon_item: &ItemStack,
        attacker: &dyn LivingEntity,
    ) -> DamageSource {
        let damage_source = if let Some(damage_type) = weapon_item.get_damage_type() {
            DamageSource::environment(damage_type)
        } else {
            ITEM_BEHAVIORS
                .get_behavior(weapon_item.item())
                .get_item_damage_source(attacker)
                .unwrap_or_else(|| DamageSource::environment(&vanilla_damage_types::MOB_ATTACK))
        };

        damage_source
            .with_causing_entity(self.id())
            .with_direct_entity(self.id())
            .with_source_position(self.position())
    }

    /// Returns vanilla `LivingEntity.getKnockback` for mob attacks.
    fn get_attack_knockback(
        &self,
        target: &dyn Entity,
        weapon_item: &ItemStack,
        damage_source: &DamageSource,
    ) -> f64 {
        let attack_knockback = self
            .attributes()
            .lock()
            .required_value(vanilla_attributes::ATTACK_KNOCKBACK);
        let enchantment_context = EnchantmentDamageContext::new(
            target.entity_type(),
            Some(self.entity_type()),
            Some(self.entity_type()),
            damage_source,
        );
        let modified = enchantment_helper::modify_knockback(
            weapon_item,
            &enchantment_context,
            attack_knockback as f32,
        );
        f64::from(modified) / 2.0
    }

    /// Applies vanilla `LivingEntity.causeExtraKnockback`.
    fn cause_extra_knockback(
        &self,
        target: &dyn Entity,
        knockback_amount: f64,
        _old_movement: DVec3,
    ) {
        if knockback_amount <= 0.0 {
            return;
        }
        let Some(living_target) = target.as_living_entity() else {
            return;
        };

        let yaw_radians = self.rotation().0.to_radians();
        let yaw_sin = f64::from(yaw_radians.sin());
        let yaw_cos = f64::from(yaw_radians.cos());
        living_target.knockback(knockback_amount, yaw_sin, -yaw_cos);

        let velocity = self.velocity();
        self.set_velocity(DVec3::new(velocity.x * 0.6, velocity.y, velocity.z * 0.6));
    }

    /// Plays vanilla `LivingEntity.playAttackSound`.
    fn play_attack_sound(&self) {}

    /// Returns vanilla `Mob.isWithinMeleeAttackRange`.
    fn is_within_melee_attack_range(&self, target: &dyn LivingEntity) -> bool {
        // TODO: Use the held item's ATTACK_RANGE component once it has typed component data.
        let max_range = default_attack_reach();
        let min_range = 0.0;
        let target_hitbox = target.bounding_box();
        self.attack_bounding_box(max_range)
            .intersects(target_hitbox)
            && (min_range <= 0.0
                || !self
                    .attack_bounding_box(min_range)
                    .intersects(target_hitbox))
    }

    /// Returns vanilla `Mob.getAttackBoundingBox`.
    fn attack_bounding_box(&self, horizontal_expansion: f64) -> WorldAabb {
        let own_aabb = self.bounding_box();
        let base = if let Some(vehicle) = self.vehicle() {
            let mount_aabb = vehicle.bounding_box();
            WorldAabb::new(
                own_aabb.min_x().min(mount_aabb.min_x()),
                own_aabb.min_y(),
                own_aabb.min_z().min(mount_aabb.min_z()),
                own_aabb.max_x().max(mount_aabb.max_x()),
                own_aabb.max_y(),
                own_aabb.max_z().max(mount_aabb.max_z()),
            )
        } else {
            own_aabb
        };

        base.inflate_xyz(horizontal_expansion, 0.0, horizontal_expansion)
    }

    fn set_aggressive(&self, aggressive: bool) {
        self.set_mob_flag(MOB_FLAG_AGGRESSIVE, aggressive);
    }

    fn set_mob_flag(&self, flag: i8, enabled: bool) {
        let flags = self.mob_flags();
        let next = if enabled { flags | flag } else { flags & !flag };
        self.set_mob_flags(next);
    }

    fn controlled_mob_vehicle(&self) -> Option<SharedEntity> {
        let vehicle = self.vehicle()?;
        if vehicle
            .controlling_passenger()
            .is_none_or(|passenger| passenger.id() != self.id())
        {
            return None;
        }
        vehicle.as_mob()?;
        Some(vehicle)
    }

    fn set_wanted_position(&self, position: DVec3, speed_modifier: f64) {
        if let Some(vehicle) = self.controlled_mob_vehicle()
            && let Some(mob) = vehicle.as_mob()
        {
            mob.set_wanted_position(position, speed_modifier);
            return;
        }

        self.mob_base()
            .controls()
            .lock()
            .move_control
            .set_wanted_position(position, speed_modifier);
    }

    fn jump_control_jump(&self) {
        self.mob_base().controls().lock().jump_control.jump();
    }

    /// Mirrors vanilla `Mob.setSpeed`: update cached speed and forward AI input.
    fn set_mob_speed(&self, speed: f32) {
        self.set_speed(speed);
        let input = self.travel_input();
        self.set_travel_input(LivingTravelInput::new(
            input.sideways(),
            input.vertical(),
            speed,
        ));
    }

    fn mob_server_ai_step(&self) {
        self.increment_no_action_time();
        self.mob_base().sensing().lock().tick();
        if self.tick_count() % 5 == 0 {
            self.update_control_flags();
        }
        self.tick_goal_selectors();
        self.tick_path_navigation();
        self.custom_server_ai_step();
        self.tick_move_control();
        self.tick_look_control();
        self.tick_jump_control();
    }

    /// Vanilla `Mob.aiStep`: the `LivingEntity.aiStep` movement foundation followed
    /// by the item-pickup looting loop.
    ///
    /// Looting lives here rather than in [`mob_server_ai_step`](Self::mob_server_ai_step)
    /// because vanilla runs it from `aiStep`, not `serverAiStep`: a mob with
    /// `NoAI` set still collects loot, so the looting must not sit behind the
    /// `isEffectiveAi` gate that guards the goal/navigation ticks.
    fn mob_ai_step(&self) -> Option<MoveResult> {
        let result = self.default_ai_step();
        self.tick_looting();
        result
    }

    fn tick_path_navigation(&self) {
        let Some(world) = self.level() else {
            return;
        };
        let game_time = world.game_time();
        self.mob_base().navigation().lock().tick();
        tick_path_navigation_target(self, &world, game_time, true);
    }

    fn tick_move_control(&self) {
        let move_control = {
            let mut controls = self.mob_base().controls().lock();
            let move_control = controls.move_control;
            if matches!(move_control.operation(), MoveControlOperation::MoveTo) {
                controls.move_control.set_wait();
            }
            move_control
        };

        match move_control.operation() {
            MoveControlOperation::Wait => {
                let input = self.travel_input();
                self.set_travel_input(LivingTravelInput::new(
                    input.sideways(),
                    input.vertical(),
                    0.0,
                ));
            }
            MoveControlOperation::MoveTo => self.tick_move_to_control(
                move_control.wanted_position(),
                move_control.speed_modifier(),
            ),
            MoveControlOperation::Strafe => {
                self.tick_strafe_control(
                    move_control.strafe_forward(),
                    move_control.strafe_right(),
                );
            }
            MoveControlOperation::Jumping => {
                self.tick_jumping_control(move_control.speed_modifier());
            }
        }
    }

    fn tick_move_to_control(&self, wanted_position: DVec3, speed_modifier: f64) {
        let position = self.position();
        let xd = wanted_position.x - position.x;
        let yd = wanted_position.y - position.y;
        let zd = wanted_position.z - position.z;
        let dd = xd * xd + yd * yd + zd * zd;
        if dd < MOVE_CONTROL_MIN_SPEED_SQR {
            let input = self.travel_input();
            self.set_travel_input(LivingTravelInput::new(
                input.sideways(),
                input.vertical(),
                0.0,
            ));
            return;
        }

        let y_rot = (zd.atan2(xd) as f32 * 180.0 / PI) - 90.0;
        let (_, pitch) = self.rotation();
        self.set_rotation((
            rotlerp(self.rotation().0, y_rot, MOVE_CONTROL_MAX_TURN),
            pitch,
        ));
        let movement_speed = self
            .attributes()
            .lock()
            .required_value(vanilla_attributes::MOVEMENT_SPEED);
        self.set_mob_speed((speed_modifier * movement_speed) as f32);

        if should_jump_to_wanted_position(self, xd, yd, zd) {
            self.jump_control_jump();
            self.mob_base().controls().lock().move_control.set_jumping();
        }
    }

    fn tick_strafe_control(&self, forward: f32, right: f32) {
        let movement_speed = self
            .attributes()
            .lock()
            .required_value(vanilla_attributes::MOVEMENT_SPEED) as f32;
        let speed = movement_speed * 0.25;
        let mut strafe_forward = forward;
        let mut strafe_right = right;

        let mut distance = strafe_forward
            .mul_add(strafe_forward, strafe_right * strafe_right)
            .sqrt();
        if distance < 1.0 {
            distance = 1.0;
        }
        distance = speed / distance;
        let xa = strafe_forward * distance;
        let za = strafe_right * distance;
        let yaw_radians = self.rotation().0 * PI / 180.0;
        let sin = yaw_radians.sin();
        let cos = yaw_radians.cos();
        let dx = xa.mul_add(cos, -(za * sin));
        let dz = za.mul_add(cos, xa * sin);
        if !self.is_strafe_walkable(dx, dz) {
            strafe_forward = 1.0;
            strafe_right = 0.0;
        }

        self.set_speed(speed);
        self.set_travel_input(LivingTravelInput::new(strafe_right, 0.0, strafe_forward));
        self.mob_base().controls().lock().move_control.set_wait();
    }

    fn is_strafe_walkable(&self, dx: f32, dz: f32) -> bool {
        let Some(world) = self.level() else {
            return true;
        };
        let position = self.position();
        let pos = BlockPos::new(
            fast_floor(position.x + f64::from(dx)),
            fast_floor(position.y),
            fast_floor(position.z + f64::from(dz)),
        );
        let mut context = PathfindingContext::new(world.as_ref(), self.block_position());
        WalkPathEvaluator::path_type_static(&mut context, pos) == PathType::Walkable
    }

    fn tick_jumping_control(&self, speed_modifier: f64) {
        let movement_speed = self
            .attributes()
            .lock()
            .required_value(vanilla_attributes::MOVEMENT_SPEED);
        self.set_mob_speed((speed_modifier * movement_speed) as f32);
        if self.on_ground()
            || (self.is_in_water() || self.is_in_lava()) && self.is_affected_by_fluids()
        {
            self.mob_base().controls().lock().move_control.set_wait();
        }
    }

    fn tick_look_control(&self) {
        let look_control = {
            let mut controls = self.mob_base().controls().lock();
            let look_control = controls.look_control;
            controls.look_control.tick_cooldown();
            look_control
        };

        let mut rotation = self.rotation();
        rotation.1 = 0.0;
        if look_control.is_looking_at_target() {
            let position = self.position();
            let wanted_position = look_control.wanted_position();
            let xd = wanted_position.x - position.x;
            let yd = wanted_position.y - self.get_eye_y();
            let zd = wanted_position.z - position.z;
            let horizontal = xd.hypot(zd);
            if horizontal.abs() > 1.0e-5 || yd.abs() > 1.0e-5 {
                let target_pitch = -(yd.atan2(horizontal)) as f32 * 180.0 / PI;
                rotation.1 =
                    rotate_towards(rotation.1, target_pitch, look_control.x_max_rot_angle());
            }
            if zd.abs() > 1.0e-5 || xd.abs() > 1.0e-5 {
                let target_yaw = (zd.atan2(xd) as f32 * 180.0 / PI) - 90.0;
                self.set_y_head_rot(rotate_towards(
                    self.y_head_rot(),
                    target_yaw,
                    look_control.y_max_rot_speed(),
                ));
            }
        } else {
            self.set_y_head_rot(rotate_towards(self.y_head_rot(), self.y_body_rot(), 10.0));
        }

        self.set_rotation(rotation);
        self.clamp_head_rotation_to_body_when_pathing();
    }

    fn clamp_head_rotation_to_body_when_pathing(&self) {
        if self.mob_base().navigation().lock().is_done() {
            return;
        }

        self.set_y_head_rot(rotate_if_necessary(
            self.y_head_rot(),
            self.y_body_rot(),
            self.max_head_y_rot(),
        ));
    }

    fn tick_jump_control(&self) {
        let jumping = self.mob_base().controls().lock().jump_control.tick();
        self.set_jumping(jumping);
    }

    fn update_control_flags(&self) {
        let no_controller = self
            .controlling_passenger()
            .is_none_or(|passenger| !passenger.is_mob());
        let not_in_boat = self
            .vehicle()
            .is_none_or(|vehicle| !vehicle.entity_type().is_abstract_boat);

        let mut selector = self.mob_base().goal_selector().lock();
        selector.set_control(GoalControl::Move, no_controller);
        selector.set_control(GoalControl::Jump, no_controller && not_in_boat);
        selector.set_control(GoalControl::Look, no_controller);
    }

    fn tick_body_rotation_control(&self) {
        let moving = {
            let delta = self.position() - self.old_position();
            delta.x.mul_add(delta.x, delta.z * delta.z) > BODY_ROTATION_MOVING_DISTANCE_SQR
        };
        let carrying_mob_passenger = self
            .first_passenger()
            .is_some_and(|passenger| passenger.is_mob());
        let input = BodyRotationInput::new(
            moving,
            carrying_mob_passenger,
            self.rotation().0,
            self.y_body_rot(),
            self.y_head_rot(),
            self.max_head_y_rot(),
        );
        let update = self
            .mob_base()
            .controls()
            .lock()
            .body_rotation_control
            .tick(input);
        self.set_y_body_rot(update.y_body_rot());
        self.set_y_head_rot(update.y_head_rot());
    }
}

// Blanket implementation for all mobs to implement `Leashable`
impl<T: Mob> Leashable for T {
    fn leash_data(&self) -> &SyncMutex<Option<LeashData>> {
        self.mob_base().leash_data()
    }
}

fn can_attempt_equipment_drop(drop_chance: f32, preserve: bool, killed_by_player: bool) -> bool {
    drop_chance != 0.0 && (killed_by_player || preserve)
}

fn default_attack_reach() -> f64 {
    f64::from(DEFAULT_ATTACK_REACH_BASE).sqrt() - f64::from(DEFAULT_ATTACK_REACH_OFFSET)
}

fn should_jump_to_wanted_position<M: Mob + ?Sized>(mob: &M, xd: f64, yd: f64, zd: f64) -> bool {
    let max_up_step = f64::from(mob.max_up_step());
    if yd > max_up_step && xd * xd + zd * zd < mob.bounding_box().width().max(1.0) {
        return true;
    }

    let Some(world) = mob.level() else {
        return false;
    };
    let pos = mob.block_position();
    let block_state = world.get_block_state(pos);
    let behavior = BLOCK_BEHAVIORS.get_behavior(block_state.get_block());
    let shape = behavior.get_collision_shape(
        block_state,
        world.as_ref(),
        pos,
        BlockCollisionContext::empty(),
    );
    let shape_top = position_shape_top(pos, shape.max(Axis::Y));
    let block = block_state.get_block();
    !shape.is_empty()
        && mob.position().y < shape_top
        && !block.has_tag(&BlockTag::DOORS)
        && !block.has_tag(&BlockTag::FENCES)
}

fn position_shape_top(pos: BlockPos, local_y: f64) -> f64 {
    f64::from(pos.y()) + local_y
}

fn block_pos_distance_sqr(a: BlockPos, b: BlockPos) -> f64 {
    let dx = f64::from(a.x() - b.x());
    let dy = f64::from(a.y() - b.y());
    let dz = f64::from(a.z() - b.z());
    dx.mul_add(dx, dy.mul_add(dy, dz * dz))
}

fn block_center_distance_sqr(pos: BlockPos, target: DVec3) -> f64 {
    let (x, y, z) = pos.get_center();
    DVec3::new(x, y, z).distance_squared(target)
}

fn home_radius_sqr(radius: i32) -> f64 {
    let radius = f64::from(radius);
    radius * radius
}

fn rotlerp(a: f32, b: f32, max: f32) -> f32 {
    let mut diff = wrap_degrees(b - a);
    if diff > max {
        diff = max;
    }
    if diff < -max {
        diff = -max;
    }

    let mut result = a + diff;
    if result < 0.0 {
        result += 360.0;
    } else if result > 360.0 {
        result -= 360.0;
    }
    result
}

fn wrap_degrees(mut degrees: f32) -> f32 {
    degrees %= 360.0;
    if degrees >= 180.0 {
        degrees -= 360.0;
    }
    if degrees < -180.0 {
        degrees += 360.0;
    }
    degrees
}

#[cfg(test)]
mod tests;
